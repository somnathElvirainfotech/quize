import React from 'react'

function NotFound() {
  return (
    <center>Page NotFound</center>
  )
}

export default NotFound