import React from 'react'

function Loader() {
  return (
         <div className="bg-loader">
	        <div className="loader" />
        </div>
  )
    
  
}

export default Loader